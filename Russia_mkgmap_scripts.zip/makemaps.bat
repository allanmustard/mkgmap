rem script for generating Garmin maps for Russia, version of October 9, 2026
rem this script assumes you have 16Gb RAM on your computer so Xmx parameter in mkgmap is set at 16384 Mb. If your RAM is lower, reduce Xmx parameter to fit your available RAM. 
rem
time /t > logfile.txt
echo "Central Federal District" >> logfile.txt
rem
java.exe -Xmx8192m -jar splitter\splitter.jar --output-dir=split\cen --description=CenFedDist --overlap=4000 --keep-complete=true --max-nodes=600000  --mapid=12310001 pbf\central-fed-district-latest.osm.pbf
rem
java.exe -Xmx16384m -jar mkgmap\mkgmap.jar --copyright-message="Copyright OpenStreetMap and contributors" --output-dir=map\cen --route --index --split-name-index --road-name-config=.\russia\roadnameconfig.txt --location-autofill=is_in,nearest  --preserve-element-order --style-file=.\russia --reduce-point-density --reduce-point-density-polygon  --add-pois-to-areas --link-pois-to-ways --nearby-poi-rules-config=.\russia\duppoi  --unicode --housenumbers --road-name-pois --process-exits --process-destination --add-boundary-nodes-at-admin-boundaries=2 --housenumbers --poi-address --precomp-sea=sea.zip --bounds=bounds.zip --generate-sea --country-name=Russia --family-id=1231 --family-name=CenFedDist --area-name=CenFedDist --gmapi --gmapsupp -c split\cen\template.args 
rem
rem ---
rem
echo "Far Eastern Federal District" >> logfile.txt
time /t >> logfile.txt
rem
java.exe -Xmx8192m -jar splitter\splitter.jar --output-dir=split\far --description=FarEast --overlap=4000 --keep-complete=true --max-nodes=600000  --mapid=12320001 pbf\far-eastern-fed-district-latest.osm.pbf
rem
java.exe -Xmx16384m -jar mkgmap\mkgmap.jar --copyright-message="Copyright OpenStreetMap and contributors" --output-dir=map\far --route --index --split-name-index --road-name-config=.\russia\roadnameconfig.txt --location-autofill=is_in,nearest  --preserve-element-order --style-file=.\russia --reduce-point-density --reduce-point-density-polygon --add-pois-to-areas --link-pois-to-ways --nearby-poi-rules-config=.\russia\duppoi  --unicode --housenumbers --road-name-pois --process-exits --process-destination --add-boundary-nodes-at-admin-boundaries=2 --housenumbers --poi-address --precomp-sea=sea.zip --bounds=bounds.zip --generate-sea --country-name=Russia --family-id=1232 --family-name=FarEast --area-name=FarEast --gmapi --gmapsupp -c split\far\template.args 
rem
rem ---
rem
echo "Kaliningrad" >> logfile.txt
time /t >> logfile.txt
rem
java.exe -Xmx8192m -jar splitter\splitter.jar --output-dir=split\kal --description=Kaliningrad --overlap=4000 --keep-complete=true --max-nodes=600000  --mapid=12330001 pbf\kaliningrad-latest.osm.pbf
rem
java.exe -Xmx16384m -jar mkgmap\mkgmap.jar --copyright-message="Copyright OpenStreetMap and contributors" --output-dir=map\kal --route --index --split-name-index --road-name-config=.\russia\roadnameconfig.txt --location-autofill=is_in,nearest  --preserve-element-order --style-file=.\russia --reduce-point-density --reduce-point-density-polygon --add-pois-to-areas --link-pois-to-ways --nearby-poi-rules-config=.\russia\duppoi  --unicode --housenumbers --road-name-pois --process-exits --process-destination --add-boundary-nodes-at-admin-boundaries=2 --housenumbers --poi-address --precomp-sea=sea.zip --bounds=bounds.zip --generate-sea --country-name=Russia --family-id=1233 --family-name=Kaliningrad --area-name=Kaliningrad --gmapi --gmapsupp -c split\kal\template.args 
rem
rem ---
rem
echo "North Caucasus Federal District" >> logfile.txt
time /t >> logfile.txt
rem
java.exe -Xmx8192m -jar splitter\splitter.jar --output-dir=split\nca --description=NCaucasus --overlap=4000 --keep-complete=true --max-nodes=600000  --mapid=12340001 pbf\north-caucasus-fed-district-latest.osm.pbf
rem
java.exe -Xmx16384m -jar mkgmap\mkgmap.jar --copyright-message="Copyright OpenStreetMap and contributors" --output-dir=map\nca --route --index --split-name-index --road-name-config=.\russia\roadnameconfig.txt --location-autofill=is_in,nearest  --preserve-element-order --style-file=.\russia --reduce-point-density --reduce-point-density-polygon --add-pois-to-areas --link-pois-to-ways --nearby-poi-rules-config=.\russia\duppoi  --unicode --housenumbers --road-name-pois --process-exits --process-destination --add-boundary-nodes-at-admin-boundaries=2 --housenumbers --poi-address --precomp-sea=sea.zip --bounds=bounds.zip --generate-sea --country-name=Russia --family-id=1234 --family-name=NCaucasus --area-name=NCaucasus --gmapi --gmapsupp -c split\nca\template.args 
rem
rem ---
rem
echo "Northwest Federal District" >> logfile.txt
time /t >> logfile.txt
rem  This district is dense so max-nodes needs to be set low
java.exe -Xmx8192m -jar splitter\splitter.jar --output-dir=split\nw --description=NWFedDist --overlap=4000 --keep-complete=true --max-nodes=600000  --mapid=12350001 pbf\northwestern-fed-district-latest.osm.pbf
rem
java.exe -Xmx16384m -jar mkgmap\mkgmap.jar --copyright-message="Copyright OpenStreetMap and contributors" --output-dir=map\nw --route --index --split-name-index --road-name-config=.\russia\roadnameconfig.txt --location-autofill=is_in,nearest  --preserve-element-order --style-file=.\russia --reduce-point-density --reduce-point-density-polygon --add-pois-to-areas --link-pois-to-ways --nearby-poi-rules-config=.\russia\duppoi  --unicode --housenumbers --road-name-pois --process-exits --process-destination --add-boundary-nodes-at-admin-boundaries=2 --housenumbers --poi-address --precomp-sea=sea.zip --bounds=bounds.zip --generate-sea --country-name=Russia --family-id=1235 --family-name=NWFedDist --area-name=NWFedDist --keep-going --gmapi --gmapsupp -c split\nw\template.args 
rem ---
rem
echo "Siberian Federal District" >> logfile.txt
time /t >> logfile.txt
rem
java.exe -Xmx8192m -jar splitter\splitter.jar --output-dir=split\sib --description=Siberia --overlap=4000 --keep-complete=true --max-nodes=600000  --mapid=12360001 pbf\siberian-fed-district-latest.osm.pbf
rem
java.exe -Xmx16384m -jar mkgmap\mkgmap.jar --copyright-message="Copyright OpenStreetMap and contributors" --output-dir=map\sib --route --index --split-name-index --road-name-config=.\russia\roadnameconfig.txt --location-autofill=is_in,nearest  --preserve-element-order --style-file=.\russia --reduce-point-density --reduce-point-density-polygon --add-pois-to-areas --link-pois-to-ways --nearby-poi-rules-config=.\russia\duppoi  --unicode --housenumbers --road-name-pois --process-exits --process-destination --add-boundary-nodes-at-admin-boundaries=2 --housenumbers --poi-address --precomp-sea=sea.zip --bounds=bounds.zip --generate-sea --country-name=Russia --family-id=1236 --family-name=Siberia --area-name=Siberia --gmapi --gmapsupp -c split\sib\template.args 
rem
rem ---
rem
echo "Southern Federal District" >> logfile.txt
time /t >> logfile.txt
rem
java.exe -Xmx8192m -jar splitter\splitter.jar --output-dir=split\sfd --description=SFedDist --overlap=4000 --keep-complete=true --max-nodes=600000  --mapid=12370001 pbf\south-fed-district-latest.osm.pbf
rem
java.exe -Xmx16384m -jar mkgmap\mkgmap.jar --copyright-message="Copyright OpenStreetMap and contributors" --output-dir=map\sfd --route --index --split-name-index --road-name-config=.\russia\roadnameconfig.txt --location-autofill=is_in,nearest  --preserve-element-order --style-file=.\russia --reduce-point-density --reduce-point-density-polygon --add-pois-to-areas --link-pois-to-ways --nearby-poi-rules-config=.\russia\duppoi  --unicode --housenumbers --road-name-pois --process-exits --process-destination --add-boundary-nodes-at-admin-boundaries=2 --housenumbers --poi-address --precomp-sea=sea.zip --bounds=bounds.zip --generate-sea --country-name=Russia --family-id=1237 --family-name=SFedDist --area-name=SFedDist --gmapi --gmapsupp -c split\sfd\template.args 
rem
rem ---
rem
echo "Urals Federal District" >> logfile.txt
time /t >> logfile.txt
rem
java.exe -Xmx8192m -jar splitter\splitter.jar --output-dir=split\ura --description=Ural --overlap=4000 --keep-complete=true --max-nodes=600000  --mapid=12380001 pbf\ural-fed-district-latest.osm.pbf
rem
java.exe -Xmx16384m -jar mkgmap\mkgmap.jar --copyright-message="Copyright OpenStreetMap and contributors" --output-dir=map\ura --route --index --split-name-index --road-name-config=.\russia\roadnameconfig.txt --location-autofill=is_in,nearest  --preserve-element-order --style-file=.\russia --reduce-point-density --reduce-point-density-polygon --add-pois-to-areas --link-pois-to-ways --nearby-poi-rules-config=.\russia\duppoi  --unicode --housenumbers --road-name-pois --process-exits --process-destination --add-boundary-nodes-at-admin-boundaries=2 --housenumbers --poi-address --precomp-sea=sea.zip --bounds=bounds.zip --generate-sea --country-name=Russia --family-id=1238 --family-name=Ural --area-name=Ural --gmapi --gmapsupp -c split\ura\template.args 
rem
rem ---
rem
echo "Volga Federal District" >> logfile.txt
time /t >> logfile.txt
rem
java.exe -Xmx8192m -jar splitter\splitter.jar --output-dir=split\vlg --description=Volga --overlap=4000 --keep-complete=true --max-nodes=600000  --mapid=12390001 pbf\volga-fed-district-latest.osm.pbf
rem
java.exe -Xmx16384m -jar mkgmap\mkgmap.jar --copyright-message="Copyright OpenStreetMap and contributors" --output-dir=map\vlg --route --index --split-name-index --road-name-config=.\russia\roadnameconfig.txt --location-autofill=is_in,nearest  --preserve-element-order --style-file=.\russia --reduce-point-density --reduce-point-density-polygon --add-pois-to-areas --link-pois-to-ways --nearby-poi-rules-config=.\russia\duppoi  --unicode --housenumbers --road-name-pois --process-exits --process-destination --add-boundary-nodes-at-admin-boundaries=2 --housenumbers --poi-address --precomp-sea=sea.zip --bounds=bounds.zip --bounds=bounds.zip --generate-sea --country-name=Russia --family-id=1239 --family-name=Volga --area-name=Volga --gmapi --gmapsupp -c split\vlg\template.args 
rem
rem ---- rename the IMG and GMAP files so they don't overwrite each other
echo "Renaming IMG files" >> logfile.txt
time /t >> logfile.txt
rem
ren map\cen\gmapsupp.img central.img
ren map\far\gmapsupp.img fareast.img
ren map\kal\gmapsupp.img kalinin.img
ren map\nca\gmapsupp.img norcauc.img
ren map\nw\gmapsupp.img norwest.img
ren map\sfd\gmapsupp.img south.img
ren map\sib\gmapsupp.img siberia.img
ren map\ura\gmapsupp.img ural.img
ren map\vlg\gmapsupp.img volga.img
rem
rem --- move the IMG and GMAP files to a single directory to ease copying to the microSD card
echo "Copying IMG files to the IMG subfolder" >> logfile.txt
time /t >> logfile.txt
cd img
copy /y ..\map\cen\central.img
copy /y ..\map\far\fareast.img
copy /y ..\map\kal\kalinin.img
copy /y ..\map\nca\norcauc.img
copy /y ..\map\nw\norwest.img
copy /y ..\map\sfd\south.img
copy /y ..\map\sib\siberia.img
copy /y ..\map\ura\ural.img
copy /y ..\map\vlg\volga.img
dir *.img
rem
echo "You will need to copy these IMG files to the \Garmin folder on your GPS navigator's microSD card."
rem
echo "Copying GMAP folders to the IMG subfolder" >> ..\logfile.txt
time /t >> ..\logfile.txt
robocopy ..\map\cen\CenFedDist.gmap ..\img\central.gmap  /E 
robocopy ..\map\far\FarEast.gmap ..\img\fareast.gmap  /E
robocopy ..\map\kal\Kaliningrad.gmap ..\img\kalinin.gmap  /E
robocopy ..\map\nca\NCaucasus.gmap ..\img\norcauc.gmap  /E
robocopy ..\map\nw\NWFedDist.gmap ..\img\norwest.gmap  /E
robocopy ..\map\sfd\SFedDist.gmap ..\img\south.gmap  /E
robocopy ..\map\sib\Siberia.gmap ..\img\siberia.gmap  /E
robocopy ..\map\ura\Ural.gmap ..\img\ural.gmap  /E
robocopy ..\map\vlg\Volga.gmap ..\img\volga.gmap  /E
dir *.gmap
rem
echo "You may copy the GMAP folders to the ..\Garmin\Basecamp\Maps folder on your computer to use them in Basecamp."
rem -- delete unneeded files
echo deleting temporary split files >> ..\logfile.txt
time /t >> ..\logfile.txt
cd ..\split
del /q cen\*.*
del /q far\*.*
del /q kal\*.*
del /q nca\*.*
del /q nw\*.*
del /q sfd\*.*
del /q sib\*.*
del /q ura\*.*
del /q vlg\*.*
rem
echo deleting temporary img work files >> ..\logfile.txt
time /t >> ..\logfile.txt
cd ..\map
del /q cen\*.*
del /q far\*.*
del /q kal\*.*
del /q nca\*.*
del /q nw\*.*
del /q sfd\*.*
del /q sib\*.*
del /q ura\*.*
del /q vlg\*.*
echo deleting GMAP files from map subfolders >> ..\logfile.txt
time /t >> ..\\logfile.txt
rmdir cen\CenFedDist.gmap /S /Q 
rmdir far\FarEast.gmap /S /Q
rmdir kal\Kaliningrad.gmap /S /Q
rmdir nca\NCaucasus.gmap /S /Q
rmdir nw\NWFedDist.gmap /S /Q
rmdir sfd\SFedDist.gmap /S /Q
rmdir sib\Siberia.gmap /S /Q
rmdir ura\Ural.gmap /S /Q
rmdir vlg\Volga.gmap /S /Q
rem
cd ..
time /t >> logfile.txt
echo "Finished." >> logfile.txt
