rem script for generating Garmin maps for Central Asia, version of October 10, 2026
rem this script assumes you have 16Gb RAM on your computer so Xmx parameter in mkgmap is set at 16384 Mb. If your RAM is lower, reduce Xmx parameter to fit your available RAM. 
rem this script also assumes that your input PBF files are named as shown below, i.e., <country name>.pbf
rem output will be img files named <country name>.img and gmap folders for Basecamp named <Country name>.gmap
rem
time /t > logfile.txt
echo "Kazakhstan" >> logfile.txt
rem
java.exe -Xmx4000m -jar splitter\splitter.jar --output-dir=split --max-nodes=600000 --description=Kazakhstan --overlap=4000 --keep-complete=true --mapid=12340001 kazakhstan.pbf
rem
java.exe -Xmx16384m -jar mkgmap\mkgmap.jar --copyright-message="Copyright OpenStreetMap and contributors" --output-dir=map --route --index --split-name-index --location-autofill=is_in,nearest  --preserve-element-order --style-file=.\tstan --reduce-point-density  --reduce-point-density-polygon --add-pois-to-areas --link-pois-to-ways --nearby-poi-rules-config=.\tstan\duppoi  --unicode --housenumbers --road-name-pois  --process-exits --process-destination --split-name-index --add-boundary-nodes-at-admin-boundaries=2 --housenumbers --poi-address --precomp-sea=sea.zip --bounds=bounds.zip --generate-sea  --country-name="Kazakhstan" --family-id=1234 --family-name=Kazakhstan --series-name=Central_Asia --area-name=Kazakhstan --gmapi --gmapsupp -c split\template.args 
rem Rename and move files
move /Y map\gmapsupp.img .\kazakhstan.img
robocopy map\Kazakhstan.gmap .\GMAP\Kazakhstan.gmap /E
del /q map\*.*
rmdir map\Kazakhstan.gmap /S /Q
del /q split\*.*
rem ---
rem
echo "Kyrgyzstan" >> logfile.txt
time /t >> logfile.txt
rem
java.exe -Xmx4000m -jar splitter\splitter.jar --output-dir=split --max-nodes=600000 --description=Kyrgyzstan --overlap=4000 --keep-complete=true --mapid=12350001 kyrgyzstan.pbf
rem
java.exe -Xmx16384m -jar mkgmap\mkgmap.jar --copyright-message="Copyright OpenStreetMap and contributors" --output-dir=map --route --index --split-name-index --location-autofill=is_in,nearest  --preserve-element-order --style-file=.\tstan --reduce-point-density  --reduce-point-density-polygon  --add-pois-to-areas --link-pois-to-ways --nearby-poi-rules-config=.\tstan\duppoi  --unicode --housenumbers --road-name-pois  --process-exits --process-destination --split-name-index --add-boundary-nodes-at-admin-boundaries=2 --housenumbers --poi-address --precomp-sea=sea.zip --bounds=bounds.zip --generate-sea --country-name="Kyrgyzstan" --family-id=1235 --family-name=Kyrgyzstan --series-name=Central_Asia --area-name=Kyrgyzstan --gmapi --gmapsupp -c split\template.args 
rem Rename and move files
move /Y map\gmapsupp.img .\kyrgyzstan.img
robocopy map\Kyrgyzstan.gmap .\GMAP\Kyrgyzstan.gmap /E
del /q map\*.*
rmdir map\Kyrgyzstan.gmap /S /Q
del /q split\*.*
rem
rem ---
rem
echo "Tajikistan" >> logfile.txt
time /t >> logfile.txt
rem
java.exe -Xmx4000m -jar splitter\splitter.jar --output-dir=split --max-nodes=600000 --description=Tajikistan --overlap=4000 --keep-complete=true --mapid=12360001 tajikistan.pbf
rem
java.exe -Xmx16384m -jar mkgmap\mkgmap.jar --copyright-message="Copyright OpenStreetMap and contributors" --output-dir=map --route --index --split-name-index --location-autofill=is_in,nearest  --preserve-element-order --style-file=.\tstan --reduce-point-density --reduce-point-density-polygon  --add-pois-to-areas --link-pois-to-ways --nearby-poi-rules-config=.\tstan\duppoi  --unicode --housenumbers --road-name-pois  --process-exits --process-destination --split-name-index --add-boundary-nodes-at-admin-boundaries=2 --housenumbers --poi-address --precomp-sea=sea.zip --bounds=bounds.zip --generate-sea --country-name="Tajikistan" --family-id=1236 --family-name=Tajikistan --series-name=Central_Asia --area-name=Tajikistan --gmapi --gmapsupp -c split\template.args 
rem
rem Rename and move files
move /Y map\gmapsupp.img .\tajikistan.img
robocopy map\Tajikistan.gmap .\GMAP\Tajikistan.gmap /E
del /q map\*.*
rmdir map\Tajikistan.gmap /S /Q
del /q split\*.*
rem ---
rem
echo "Turkmenistan" >> logfile.txt
time /t >> logfile.txt
rem
java.exe -Xmx4000m -jar splitter\splitter.jar --output-dir=split --max-nodes=600000 --description=Turkmenistan --overlap=4000 --keep-complete=true --mapid=12370001 turkmenistan.pbf
rem
java.exe -Xmx16384m -jar mkgmap\mkgmap.jar --copyright-message="Copyright OpenStreetMap and contributors" --output-dir=map --route --index --split-name-index --location-autofill=is_in,nearest  --preserve-element-order --style-file=.\tstan --reduce-point-density --reduce-point-density-polygon  --add-pois-to-areas --link-pois-to-ways --nearby-poi-rules-config=.\tstan\duppoi  --unicode --housenumbers --road-name-pois  --process-exits --process-destination --split-name-index --add-boundary-nodes-at-admin-boundaries=2 --housenumbers --poi-address --precomp-sea=sea.zip --bounds=bounds.zip --generate-sea --country-name="Turkmenistan" --family-id=1237 --family-name=Turkmenistan --series-name=Central_Asia --area-name=Turkmenistan --gmapi --gmapsupp -c split\template.args 
rem
rem Rename and move files
move /Y map\gmapsupp.img .\turkmenistan.img
robocopy map\Turkmenistan.gmap .\GMAP\Turkmenistan.gmap /E
del /q map\*.*
rmdir map\Turkmenistan.gmap /S /Q
del /q split\*.*
rem
rem ---
rem
echo "Uzbekistan" >> logfile.txt
time /t >> logfile.txt
rem  
java.exe -Xmx4000m -jar splitter\splitter.jar --output-dir=split --max-nodes=600000 --description=Uzbekistan --overlap=4000 --keep-complete=true --mapid=12380001 uzbekistan.pbf
rem
java.exe -Xmx16384m -jar mkgmap\mkgmap.jar --copyright-message="Copyright OpenStreetMap and contributors" --output-dir=map --route --index --split-name-index --location-autofill=is_in,nearest  --preserve-element-order --style-file=.\tstan --reduce-point-density --reduce-point-density-polygon  --add-pois-to-areas --link-pois-to-ways --nearby-poi-rules-config=.\tstan\duppoi  --unicode --housenumbers --road-name-pois  --process-exits --process-destination --split-name-index --add-boundary-nodes-at-admin-boundaries=2 --housenumbers --poi-address --precomp-sea=sea.zip --bounds=bounds.zip --generate-sea --country-name="Uzbekistan" --family-id=1238 --family-name=Uzbekistan --series-name=Central_Asia --area-name=Uzbekistan --gmapi --gmapsupp -c split\template.args 
rem
rem Rename and move files
move /Y map\gmapsupp.img .\uzbekistan.img
robocopy map\Uzbekistan.gmap .\GMAP\Uzbekistan.gmap /E
del /q map\*.*
rmdir map\Uzbekistan.gmap /S /Q
del /q split\*.*
rem ---
time /t >> logfile.txt
echo "Finished."
